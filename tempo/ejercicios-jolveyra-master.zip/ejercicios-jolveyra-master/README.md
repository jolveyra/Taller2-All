# Solidity Exercises

## Setup

1. Clonar el repositorio

2. Installar hardhat `npm install hardhat --save-dev`

3. Instalar dependencias `npm install`

## Description

The exercises are organized into 3 groups:

## Katas
Code algorithms that will help you familiarize yourself with the Solidity language in an easy and simple way

## Burn your cosmos
Develop medium-difficulty methods that allow you to develop your skills as a Solidity developer

## This is Sparta!!!
It is a place only for developers who are not afraid of coding